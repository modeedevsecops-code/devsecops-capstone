# modeedevsecops
I want to learn Git repositories, staging and commiting, branching and merging, collaboration (push pull and fetch) and managing real world projects with version control.
